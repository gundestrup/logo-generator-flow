module example.com/svg-template-demo

go 1.22

require github.com/h2non/bimg v1.1.9
