# Go SVG template demo

En lille generisk skabelonmotor, der erstatter `{{FELTER}}` i SVG med tekst fra JSON og billeder fra lokale PNG, JPEG, SVG, WebP eller AVIF-filer. Billeder indlejres som Base64 Data URI. Det færdige dokument kan gemmes som SVG og rasteriseres med `bimg`/`libvips`.

## Hurtigst: Docker

Krav: Docker med Compose.

```bash
docker compose up --build
```

Resultaterne ligger derefter i `output/`:

- `result.svg`
- `result.png`
- `result.webp`
- `result.jpg`
- `result.avif`

Bemærk: AVIF kræver, at den installerede libvips er bygget med AVIF/HEIF-understøttelse. Hvis din platform mangler det, kan du teste uden AVIF:

```bash
docker compose run --rm renderer -formats svg,png,webp,jpg
```

## Lokal kørsel

Krav:

- Go 1.22 eller nyere
- libvips med udviklingsfiler og `pkg-config`

Debian/Ubuntu:

```bash
sudo apt-get install libvips-dev pkg-config
go mod download
go run .
```

macOS med Homebrew:

```bash
brew install vips pkg-config
go mod download
go run .
```

## Kommandolinje

```bash
go run . \
  -template template.svg \
  -data data.json \
  -out output \
  -formats svg,png,webp,jpg,avif \
  -quality 90
```

Valgfrit kan `-width 1800` bruges til at ændre rasterbredden proportionalt.

## JSON-format

```json
{
  "text": {
    "TITLE": "Min titel"
  },
  "images": {
    "LOGO": { "source": "assets/logo.svg" },
    "PHOTO": { "source": "assets/photo.jpg" }
  }
}
```

`source` kan også være en allerede oprettet Data URI:

```json
"LOGO": { "source": "data:image/png;base64,iVBORw0..." }
```

Tekst XML-escapes automatisk. Lokale billedstier fortolkes relativt til JSON-filen. Manglende placeholders giver en tydelig fejl i stedet for et delvist output.

## Brug med VectorCraft

1. Opret designet i VectorCraft.
2. Giv tekst- og billedplaceringer værdier som `{{TITLE}}` og `{{LOGO}}` i den eksporterede SVG.
3. Tilføj tilsvarende nøgler i `data.json`.
4. Kør programmet.

Hvis en editor ændrer dobbelte krølleparenteser, kan du efter eksport åbne SVG-filen som tekst og indsætte placeholders igen.
