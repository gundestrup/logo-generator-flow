package main

import (
    "encoding/base64"
    "encoding/json"
    "errors"
    "flag"
    "fmt"
    "html"
    "os"
    "path/filepath"
    "regexp"
    "sort"
    "strings"

    "github.com/h2non/bimg"
)

type ImageField struct {
    Source string `json:"source"`
}

type TemplateData struct {
    Text   map[string]string     `json:"text"`
    Images map[string]ImageField `json:"images"`
}

var placeholderRE = regexp.MustCompile(`\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}`)

func main() {
    templatePath := flag.String("template", "template.svg", "SVG template")
    dataPath := flag.String("data", "data.json", "JSON data file")
    outDir := flag.String("out", "output", "output directory")
    formatsFlag := flag.String("formats", "svg,png,webp,jpg,avif", "comma-separated formats")
    width := flag.Int("width", 0, "optional raster width; 0 uses SVG width")
    quality := flag.Int("quality", 90, "JPEG/WebP/AVIF quality, 1-100")
    flag.Parse()

    if err := run(*templatePath, *dataPath, *outDir, *formatsFlag, *width, *quality); err != nil {
        fmt.Fprintln(os.Stderr, "error:", err)
        os.Exit(1)
    }
}

func run(templatePath, dataPath, outDir, formatsCSV string, width, quality int) error {
    if quality < 1 || quality > 100 {
        return errors.New("quality must be between 1 and 100")
    }

    templateBytes, err := os.ReadFile(templatePath)
    if err != nil {
        return fmt.Errorf("read template: %w", err)
    }

    dataBytes, err := os.ReadFile(dataPath)
    if err != nil {
        return fmt.Errorf("read data: %w", err)
    }

    var data TemplateData
    if err := json.Unmarshal(dataBytes, &data); err != nil {
        return fmt.Errorf("parse JSON: %w", err)
    }

    values := make(map[string]string)
    for key, value := range data.Text {
        values[key] = html.EscapeString(value)
    }

    baseDir := filepath.Dir(dataPath)
    for key, field := range data.Images {
        uri, err := sourceToDataURI(baseDir, field.Source)
        if err != nil {
            return fmt.Errorf("image %q: %w", key, err)
        }
        values[key] = html.EscapeString(uri)
    }

    rendered := placeholderRE.ReplaceAllStringFunc(string(templateBytes), func(token string) string {
        match := placeholderRE.FindStringSubmatch(token)
        if value, ok := values[match[1]]; ok {
            return value
        }
        return token
    })

    unresolved := unresolvedPlaceholders(rendered)
    if len(unresolved) > 0 {
        return fmt.Errorf("unresolved placeholders: %s", strings.Join(unresolved, ", "))
    }

    if err := os.MkdirAll(outDir, 0o755); err != nil {
        return fmt.Errorf("create output directory: %w", err)
    }

    formats, err := parseFormats(formatsCSV)
    if err != nil {
        return err
    }

    for _, format := range formats {
        outputPath := filepath.Join(outDir, "result."+format)
        if format == "svg" {
            if err := os.WriteFile(outputPath, []byte(rendered), 0o644); err != nil {
                return fmt.Errorf("write SVG: %w", err)
            }
            fmt.Println("wrote", outputPath)
            continue
        }

        output, err := rasterize([]byte(rendered), format, width, quality)
        if err != nil {
            return fmt.Errorf("render %s: %w", format, err)
        }
        if err := os.WriteFile(outputPath, output, 0o644); err != nil {
            return fmt.Errorf("write %s: %w", format, err)
        }
        fmt.Println("wrote", outputPath)
    }
    return nil
}

func sourceToDataURI(baseDir, source string) (string, error) {
    if strings.HasPrefix(source, "data:") {
        return source, nil
    }
    path := source
    if !filepath.IsAbs(path) {
        path = filepath.Join(baseDir, source)
    }
    content, err := os.ReadFile(path)
    if err != nil {
        return "", fmt.Errorf("read %s: %w", path, err)
    }
    mime, err := mimeFromExtension(path)
    if err != nil {
        return "", err
    }
    encoded := base64.StdEncoding.EncodeToString(content)
    return fmt.Sprintf("data:%s;base64,%s", mime, encoded), nil
}

func mimeFromExtension(path string) (string, error) {
    switch strings.ToLower(filepath.Ext(path)) {
    case ".png":
        return "image/png", nil
    case ".jpg", ".jpeg":
        return "image/jpeg", nil
    case ".svg", ".svgz":
        return "image/svg+xml", nil
    case ".webp":
        return "image/webp", nil
    case ".avif":
        return "image/avif", nil
    default:
        return "", fmt.Errorf("unsupported image extension: %s", filepath.Ext(path))
    }
}

func parseFormats(csv string) ([]string, error) {
    allowed := map[string]bool{"svg": true, "png": true, "webp": true, "jpg": true, "jpeg": true, "avif": true}
    seen := map[string]bool{}
    formats := make([]string, 0)
    for _, item := range strings.Split(csv, ",") {
        format := strings.ToLower(strings.TrimSpace(item))
        if format == "jpeg" {
            format = "jpg"
        }
        if !allowed[format] {
            return nil, fmt.Errorf("unsupported output format %q", item)
        }
        if !seen[format] {
            seen[format] = true
            formats = append(formats, format)
        }
    }
    if len(formats) == 0 {
        return nil, errors.New("no output formats selected")
    }
    return formats, nil
}

func rasterize(svg []byte, format string, width, quality int) ([]byte, error) {
    imageType := bimg.PNG
    switch format {
    case "png":
        imageType = bimg.PNG
    case "webp":
        imageType = bimg.WEBP
    case "jpg":
        imageType = bimg.JPEG
    case "avif":
        imageType = bimg.AVIF
    }

    options := bimg.Options{
        Type:       imageType,
        Width:      width,
        Quality:    quality,
        StripMetadata: true,
    }
    if format == "jpg" {
        options.Background = bimg.Color{R: 255, G: 255, B: 255}
        options.Flatten = true
    }
    return bimg.NewImage(svg).Process(options)
}

func unresolvedPlaceholders(svg string) []string {
    matches := placeholderRE.FindAllStringSubmatch(svg, -1)
    set := map[string]bool{}
    for _, match := range matches {
        set[match[1]] = true
    }
    result := make([]string, 0, len(set))
    for key := range set {
        result = append(result, key)
    }
    sort.Strings(result)
    return result
}
