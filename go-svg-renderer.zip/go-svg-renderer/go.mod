module example.com/go-svg-renderer

go 1.23
