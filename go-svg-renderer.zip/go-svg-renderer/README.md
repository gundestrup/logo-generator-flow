# Go SVG Renderer

Ren Go-applikation uden Docker og uden Node.js. Go udfylder SVG-skabelonen og indlejrer lokale billeder som Base64 Data URI. De bedste specialiserede renderere bruges til output:

- `resvg`: SVG til tabsfri PNG
- `cwebp` fra `libwebp`: PNG til WebP
- `avifenc` fra `libavif`: PNG til AVIF
- Go `image/jpeg`: PNG til JPEG med valgt baggrund

## Krav

- Go 1.23+
- `resvg`, `cwebp` og `avifenc` i PATH, eller angiv fuld sti i `config.json`

### Windows

Hent officielle/prebyggede programmer, og placer dem fx i `tools/`. Skift derefter:

```json
"tools": {
  "resvg": "tools/resvg.exe",
  "cwebp": "tools/cwebp.exe",
  "avifenc": "tools/avifenc.exe"
}
```

### macOS

```bash
brew install resvg webp libavif
go build -o svg-renderer .
./svg-renderer config.json
```

### Debian/Ubuntu

Installer `resvg`, WebP-værktøjer og libavif-værktøjer fra distributionens pakker, hvis tilgængelige. Pakkenavne varierer mellem versioner. Kontroller med:

```bash
resvg --version
cwebp -version
avifenc --version
```

Byg og kør:

```bash
chmod +x build.sh
./build.sh
./svg-renderer config.json
```

## Test

```bash
go run . config.json
```

Resultater skrives til `output/demo.*`.

## JSON-billeder

Lokale PNG, JPEG, SVG, WebP og AVIF kan bruges:

```json
"PHOTO": { "source": "assets/photo.jpg" }
```

En færdig Data URI kan også bruges:

```json
"PHOTO": { "source": "data:image/png;base64,iVBORw0..." }
```

Af sikkerheds- og reproducerbarhedsgrunde henter programmet ikke HTTP-billeder.

## Kvalitetsvalg

Demoen bruger JPEG 94, WebP 92 og AVIF 82 med YUV 4:4:4. AVIF speed 4 prioriterer kvalitet over hastighed. Ved store batchjobs kan speed 6 være et bedre kompromis. WebP kan sættes til tabsfri med `webpLossless: true`.

## Bemærkninger

- JPEG har ingen alpha. Transparens lægges på `jpegBackground`.
- Fonten skal findes på render-maskinen. For helt ens resultat på alle maskiner bør tekst konverteres til paths i designværktøjet eller en kontrolleret fontinstallation anvendes.
- `resvg` er master-rendereren. WebP og AVIF laves fra den samme PNG, så geometri og tekst bliver identisk på tværs af rasterformater.
