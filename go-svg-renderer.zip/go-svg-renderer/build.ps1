$ErrorActionPreference = "Stop"
go build -trimpath -ldflags="-s -w" -o svg-renderer.exe .
Write-Host "Bygget: svg-renderer.exe"
