package main

import (
    "bytes"
    "encoding/base64"
    "encoding/json"
    "errors"
    "fmt"
    "html"
    "image"
    "image/color"
    "image/draw"
    "image/jpeg"
    "image/png"
    "io"
    "net/url"
    "os"
    "os/exec"
    "path/filepath"
    "regexp"
    "runtime"
    "sort"
    "strconv"
    "strings"
)

type Config struct {
    Template string                 `json:"template"`
    Output   OutputConfig           `json:"output"`
    Render   RenderConfig           `json:"render"`
    Tools    ToolConfig             `json:"tools"`
    Text     map[string]string      `json:"text"`
    Images   map[string]ImageSource `json:"images"`
}

type OutputConfig struct {
    Directory string   `json:"directory"`
    BaseName  string   `json:"baseName"`
    Formats   []string `json:"formats"`
}

type RenderConfig struct {
    Width        int    `json:"width"`
    Height       int    `json:"height"`
    Background   string `json:"jpegBackground"`
    JPEGQuality  int    `json:"jpegQuality"`
    WebPQuality  int    `json:"webpQuality"`
    WebPLossless bool   `json:"webpLossless"`
    AVIFQuality  int    `json:"avifQuality"`
    AVIFSpeed    int    `json:"avifSpeed"`
}

type ToolConfig struct {
    Resvg   string `json:"resvg"`
    CWebP   string `json:"cwebp"`
    AvifEnc string `json:"avifenc"`
}

type ImageSource struct {
    Source string `json:"source"`
}

var placeholder = regexp.MustCompile(`\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}`)
var hexColor = regexp.MustCompile(`^#?([0-9a-fA-F]{6})$`)

func main() {
    configPath := "config.json"
    if len(os.Args) > 1 { configPath = os.Args[1] }
    if err := run(configPath); err != nil {
        fmt.Fprintln(os.Stderr, "FEJL:", err)
        os.Exit(1)
    }
}

func run(configPath string) error {
    cfg, baseDir, err := loadConfig(configPath)
    if err != nil { return err }
    applyDefaults(&cfg)
    if err := validateConfig(cfg); err != nil { return err }

    svg, err := renderTemplate(cfg, baseDir)
    if err != nil { return err }

    outDir := resolve(baseDir, cfg.Output.Directory)
    if err := os.MkdirAll(outDir, 0o755); err != nil { return err }
    stem := filepath.Join(outDir, cfg.Output.BaseName)
    svgPath := stem + ".svg"
    pngPath := stem + ".png"

    if err := os.WriteFile(svgPath, svg, 0o644); err != nil {
        return fmt.Errorf("skriv SVG: %w", err)
    }
    fmt.Println("skrev", svgPath)

    wanted := formatsSet(cfg.Output.Formats)
    needsPNG := wanted["png"] || wanted["jpg"] || wanted["webp"] || wanted["avif"]
    if !needsPNG { return nil }

    resvg, err := toolPath(cfg.Tools.Resvg, "resvg")
    if err != nil { return err }
    args := []string{}
    if cfg.Render.Width > 0 { args = append(args, "--width", strconv.Itoa(cfg.Render.Width)) }
    if cfg.Render.Height > 0 { args = append(args, "--height", strconv.Itoa(cfg.Render.Height)) }
    args = append(args, svgPath, pngPath)
    if err := command(resvg, args...); err != nil { return fmt.Errorf("resvg: %w", err) }
    fmt.Println("skrev", pngPath)

    if wanted["jpg"] {
        if err := pngToJPEG(pngPath, stem+".jpg", cfg.Render.JPEGQuality, cfg.Render.Background); err != nil { return err }
        fmt.Println("skrev", stem+".jpg")
    }
    if wanted["webp"] {
        cwebp, err := toolPath(cfg.Tools.CWebP, "cwebp")
        if err != nil { return err }
        args := []string{"-quiet", "-mt"}
        if cfg.Render.WebPLossless {
            args = append(args, "-lossless", "-z", "9", "-exact")
        } else {
            args = append(args, "-q", strconv.Itoa(cfg.Render.WebPQuality), "-m", "6")
        }
        args = append(args, pngPath, "-o", stem+".webp")
        if err := command(cwebp, args...); err != nil { return fmt.Errorf("cwebp: %w", err) }
        fmt.Println("skrev", stem+".webp")
    }
    if wanted["avif"] {
        avifenc, err := toolPath(cfg.Tools.AvifEnc, "avifenc")
        if err != nil { return err }
        args := []string{"--qcolor", strconv.Itoa(cfg.Render.AVIFQuality), "--qalpha", "100", "--speed", strconv.Itoa(cfg.Render.AVIFSpeed), "--yuv", "444", pngPath, stem+".avif"}
        if err := command(avifenc, args...); err != nil { return fmt.Errorf("avifenc: %w", err) }
        fmt.Println("skrev", stem+".avif")
    }
    if !wanted["png"] {
        if err := os.Remove(pngPath); err != nil && !errors.Is(err, os.ErrNotExist) { return err }
    }
    return nil
}

func loadConfig(path string) (Config, string, error) {
    b, err := os.ReadFile(path)
    if err != nil { return Config{}, "", fmt.Errorf("læs konfiguration: %w", err) }
    var cfg Config
    dec := json.NewDecoder(bytes.NewReader(b)); dec.DisallowUnknownFields()
    if err := dec.Decode(&cfg); err != nil { return Config{}, "", fmt.Errorf("ugyldig JSON: %w", err) }
    abs, err := filepath.Abs(path); if err != nil { return Config{}, "", err }
    return cfg, filepath.Dir(abs), nil
}

func applyDefaults(c *Config) {
    if c.Output.Directory == "" { c.Output.Directory = "output" }
    if c.Output.BaseName == "" { c.Output.BaseName = "result" }
    if len(c.Output.Formats) == 0 { c.Output.Formats = []string{"svg", "png", "jpg", "webp", "avif"} }
    if c.Render.Background == "" { c.Render.Background = "#ffffff" }
    if c.Render.JPEGQuality == 0 { c.Render.JPEGQuality = 92 }
    if c.Render.WebPQuality == 0 { c.Render.WebPQuality = 90 }
    if c.Render.AVIFQuality == 0 { c.Render.AVIFQuality = 80 }
    if c.Render.AVIFSpeed == 0 { c.Render.AVIFSpeed = 6 }
}

func validateConfig(c Config) error {
    if c.Template == "" { return errors.New("template mangler") }
    if c.Output.BaseName == "." || strings.ContainsAny(c.Output.BaseName, `/\\`) { return errors.New("baseName må kun være et filnavn") }
    for name, q := range map[string]int{"jpegQuality":c.Render.JPEGQuality,"webpQuality":c.Render.WebPQuality,"avifQuality":c.Render.AVIFQuality} {
        if q < 1 || q > 100 { return fmt.Errorf("%s skal være 1-100", name) }
    }
    if c.Render.AVIFSpeed < 0 || c.Render.AVIFSpeed > 10 { return errors.New("avifSpeed skal være 0-10") }
    allowed := map[string]bool{"svg":true,"png":true,"jpg":true,"jpeg":true,"webp":true,"avif":true}
    for _, f := range c.Output.Formats { if !allowed[strings.ToLower(f)] { return fmt.Errorf("ukendt format: %s", f) } }
    return nil
}

func renderTemplate(c Config, baseDir string) ([]byte, error) {
    b, err := os.ReadFile(resolve(baseDir, c.Template)); if err != nil { return nil, fmt.Errorf("læs template: %w", err) }
    vals := map[string]string{}
    for k,v := range c.Text { vals[k] = html.EscapeString(v) }
    for k,v := range c.Images {
        dataURI, err := imageDataURI(baseDir, v.Source); if err != nil { return nil, fmt.Errorf("billede %s: %w", k, err) }
        vals[k] = html.EscapeString(dataURI)
    }
    result := placeholder.ReplaceAllStringFunc(string(b), func(tok string) string {
        key := placeholder.FindStringSubmatch(tok)[1]
        if v, ok := vals[key]; ok { return v }
        return tok
    })
    missingSet := map[string]bool{}
    for _, m := range placeholder.FindAllStringSubmatch(result, -1) { missingSet[m[1]]=true }
    if len(missingSet)>0 { keys:=make([]string,0,len(missingSet)); for k:=range missingSet {keys=append(keys,k)}; sort.Strings(keys); return nil, fmt.Errorf("manglende felter: %s", strings.Join(keys,", ")) }
    return []byte(result), nil
}

func imageDataURI(baseDir, source string) (string,error) {
    if strings.HasPrefix(source,"data:") { return source,nil }
    if u, err := url.Parse(source); err == nil && u.Scheme != "" && u.Scheme != "file" { return "", errors.New("kun lokale filer eller data URI er tilladt") }
    path := resolve(baseDir, source); b,err:=os.ReadFile(path); if err!=nil{return "",err}
    mime,err:=mimeFor(path); if err!=nil{return "",err}
    return "data:"+mime+";base64,"+base64.StdEncoding.EncodeToString(b),nil
}

func mimeFor(path string)(string,error){
    switch strings.ToLower(filepath.Ext(path)){
    case ".png": return "image/png",nil
    case ".jpg",".jpeg": return "image/jpeg",nil
    case ".svg": return "image/svg+xml",nil
    case ".webp": return "image/webp",nil
    case ".avif": return "image/avif",nil
    default:return "",fmt.Errorf("ikke understøttet billedtype: %s",filepath.Ext(path))
    }
}

func pngToJPEG(src,dst string,quality int,bg string) error {
    f,err:=os.Open(src); if err!=nil{return err}; defer f.Close()
    im,err:=png.Decode(f); if err!=nil{return fmt.Errorf("decode PNG: %w",err)}
    c,err:=parseColor(bg); if err!=nil{return err}
    canvas:=image.NewRGBA(im.Bounds()); draw.Draw(canvas,canvas.Bounds(),&image.Uniform{C:c},image.Point{},draw.Src); draw.Draw(canvas,canvas.Bounds(),im,im.Bounds().Min,draw.Over)
    out,err:=os.Create(dst); if err!=nil{return err}; defer out.Close()
    return jpeg.Encode(out,canvas,&jpeg.Options{Quality:quality})
}

func parseColor(s string)(color.RGBA,error){m:=hexColor.FindStringSubmatch(s);if m==nil{return color.RGBA{},fmt.Errorf("ugyldig farve %q; brug #RRGGBB",s)};n,err:=strconv.ParseUint(m[1],16,32);if err!=nil{return color.RGBA{},err};return color.RGBA{uint8(n>>16),uint8(n>>8),uint8(n),255},nil}
func resolve(base,path string)string{if filepath.IsAbs(path){return path};return filepath.Join(base,path)}
func formatsSet(fs []string)map[string]bool{m:=map[string]bool{};for _,f:=range fs{f=strings.ToLower(f);if f=="jpeg"{f="jpg"};m[f]=true};return m}
func toolPath(configured,name string)(string,error){if configured!=""{p:=configured;if runtime.GOOS=="windows"&&!strings.HasSuffix(strings.ToLower(p),".exe"){if _,e:=os.Stat(p+".exe");e==nil{p+=".exe"}};if filepath.IsAbs(p)||strings.ContainsAny(p,`/\\`){if _,e:=os.Stat(p);e!=nil{return "",fmt.Errorf("værktøj ikke fundet: %s",p)};return p,nil};if q,e:=exec.LookPath(p);e==nil{return q,nil}};if q,e:=exec.LookPath(name);e==nil{return q,nil};return "",fmt.Errorf("%s blev ikke fundet; angiv sti under tools i config.json eller tilføj til PATH",name)}
func command(name string,args ...string)error{cmd:=exec.Command(name,args...);var out bytes.Buffer;cmd.Stdout=io.MultiWriter(os.Stdout,&out);cmd.Stderr=io.MultiWriter(os.Stderr,&out);if err:=cmd.Run();err!=nil{return fmt.Errorf("%w\n%s",err,strings.TrimSpace(out.String()))};return nil}
